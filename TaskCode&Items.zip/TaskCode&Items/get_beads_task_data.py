
import csv
import os.path
import sys

import mysql.connector as mariadb

err = False
try:
    filename = sys.argv[1] 
except:
    err = True
if err or os.path.exists(filename):
    print('''\
Please give this program a filename for CSV output. For example:

python get_beads_task_data.py test.csv

This must be a file that does not already exist.
''')
    sys.exit(-1)

try:
    f = open(filename, 'wb')
except:
    print('Could not open file {}, exiting.'.format(filename))

password = raw_input('Please enter your database password: ')

conn = mariadb.connect(
    user='s1500188',
    password=password,
    database='s1500188_db'
)

cur = conn.cursor()

field_names = ["ppt", "nbeads", "chosen", "actual"]

cur.execute(
    "select "+",".join(field_names)+" from beads_task", ()
)

writer = csv.writer(f)
writer.writerow(field_names)
for fields in cur:
    writer.writerow(["{}".format(x) for x in fields])
