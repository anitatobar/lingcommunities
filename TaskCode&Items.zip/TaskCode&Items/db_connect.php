<?php

$mysqli = new mysqli("localhost", "beads", "vr0q<a7hb>", "croft");

/* check connection */
if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}

?>