#!/usr/bin/python2.7

import cgi
import os.path

participant_counter_file = "/home/s1552951/server_data/partid.txt"
redirect_url_base = "https://edinburghppls.qualtrics.com/jfe/form/SV_9XgR87h0P9ESV13&ID="

# if file doesn't exist, create it
if not os.path.exists(participant_counter_file):
    ppt = 1
else:
    ppt = int(open(participant_counter_file).read())
    ppt += 1
open(participant_counter_file, "w").write("{}".format(ppt))

# reload!
print("Location: {}{}\n\n".format(redirect_url_base, ppt))
